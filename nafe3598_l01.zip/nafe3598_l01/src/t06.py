"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Ahmed Nafees
ID:     169053598
Email:  nafe3598@mylaurier.ca
__updated__ = "2023-09-13"
------------------------------------------------------------------------
"""
# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print('Your pay is', pay)
